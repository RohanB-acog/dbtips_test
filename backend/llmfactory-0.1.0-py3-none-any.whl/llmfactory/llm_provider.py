import json
import yaml
from requests.auth import HTTPBasicAuth
from langchain_ollama import ChatOllama
from langchain_ollama.llms import OllamaLLM
from langchain_ollama import OllamaEmbeddings

from langchain_openai import ChatOpenAI
from langchain_openai import OpenAIEmbeddings
from langchain_openai import OpenAI

from dotenv import dotenv_values


class LLMProviderFactory:
    """Factory to create LLM objects based on configuration."""

    @staticmethod
    def get_llm(provider: str, interface_type: str, **kwargs):
        if provider == "ollama":
            return OllamaProvider(**kwargs).get_interface(interface_type)
        elif provider == "openai":
            return OpenAIProvider(**kwargs).get_interface(interface_type)
        else:
            raise ValueError(f"Unsupported provider: {provider}")


class BaseLLMProvider:
    """Base class for LLM providers."""

    def __init__(self, **kwargs):
        self.config = kwargs

    def get_chat_interface(self):
        """Returns the chat interface for the provider."""
        raise NotImplementedError

    def get_embedding_interface(self):
        """Returns the embedding model interface for the provider."""
        raise NotImplementedError

    def get_legacy_model(self):
        """Returns the legacy model for the provider."""
        raise NotImplementedError

    def get_interface(self, interface_type: str):
        """Returns the requested interface type."""
        if interface_type == "chat":
            return self.get_chat_interface()
        elif interface_type == "embedding":
            return self.get_embedding_interface()
        elif interface_type == "legacy":
            return self.get_legacy_model()
        else:
            raise ValueError(f"Unsupported interface type: {interface_type}")


class OllamaProvider(BaseLLMProvider):
    """Provider for Ollama LLMs."""

    def get_chat_interface(self):
        endpoint = self.config.get("endpoint")
        username = self.config.get("username")
        password = self.config.get("password")
        model = self.config.get("model")
        additional_args = self.config.get("additional_args", {})

        if not endpoint or not username or not password or not model:
            raise ValueError("Missing required configuration for Ollama.")

        return ChatOllama(
            base_url=endpoint,
            model=model,
            client_kwargs={"auth": HTTPBasicAuth(username, password)},
            **additional_args
        )

    def get_embedding_interface(self):
        endpoint = self.config.get("endpoint")
        username = self.config.get("username")
        password = self.config.get("password")
        model = self.config.get("model")
        additional_args = self.config.get("additional_args", {})

        if not endpoint or not username or not password or not model:
            raise ValueError("Missing required configuration for Ollama.")

        return OllamaEmbeddings(
            base_url=endpoint,
            model=model,
            client_kwargs={"auth": HTTPBasicAuth(username, password)},
            **additional_args
        )

    def get_legacy_model(self):
        endpoint = self.config.get("endpoint")
        username = self.config.get("username")
        password = self.config.get("password")
        model = self.config.get("model")
        additional_args = self.config.get("additional_args", {})

        if not endpoint or not username or not password or not model:
            raise ValueError("Missing required configuration for Ollama.")

        return OllamaLLM(
            base_url=endpoint,
            model=model,
            client_kwargs={"auth": HTTPBasicAuth(username, password)},
            **additional_args
        )


class OpenAIProvider(BaseLLMProvider):
    """Provider for OpenAI LLMs."""

    def get_chat_interface(self):
        api_key = self.config.get("api_key")
        model = self.config.get("model")
        additional_args = self.config.get("additional_args", {})

        if not api_key or not model:
            raise ValueError("Missing required configuration for OpenAI.")

        return ChatOpenAI(
            model=model,
            openai_api_key=api_key,
            **additional_args
        )

    def get_embedding_interface(self):
        api_key = self.config.get("api_key")
        model = self.config.get("model")
        additional_args = self.config.get("additional_args", {})

        if not api_key or not model:
            raise ValueError("Missing required configuration for OpenAI.")

        return OpenAIEmbeddings(
            model=model,
            openai_api_key=api_key,
            **additional_args
        )

    def get_legacy_model(self):
        api_key = self.config.get("api_key")
        model = self.config.get("model")
        additional_args = self.config.get("additional_args", {})

        if not api_key or not model:
            raise ValueError("Missing required configuration for OpenAI.")

        return OpenAI(
            model=model,
            openai_api_key=api_key,
            **additional_args
        )


def load_config(config_path=None, env_path=None):
    """
    Load configuration from a file or environment variables.

    :param config_path: Path to the configuration file (JSON or YAML).
    :return: Configuration dictionary.
    """
    if config_path:
        with open(config_path, "r") as file:
            if config_path.endswith(".json"):
                return json.load(file)
            elif config_path.endswith(".yaml") or config_path.endswith(".yml"):
                return yaml.safe_load(file)
            else:
                raise ValueError("Unsupported config file format. Use JSON or YAML.")
    else:
        # Load from environment variables
        config = dotenv_values(dotenv_path=env_path)
        if len(config) == 0:
            raise ValueError("config file Not found please provide corrct path of your config")
        else:
            return config


def get_llm(config_path=None, env_path=None, interface_type="legacy"):
    """
    Create and return an LLM object based on the configuration and interface type.

    :param config_path: Path to the configuration file (optional).
    :param env_path: Path to the environment file (optional).
    :param interface_type: Type of interface to initialize ("chat", "embedding", or "legacy").
    :return: Initialized LLM object.
    """
    config = load_config(config_path, env_path)
    provider = config.pop("provider")

    if not provider:
        raise ValueError("Provider not specified in the configuration.")

    return LLMProviderFactory.get_llm(provider, interface_type, **config)
